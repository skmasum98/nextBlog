globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/5fe48c9cc91f60ec.js",
      "static/chunks/turbopack-b5bbeeff2fa2d723.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/5fe48c9cc91f60ec.js",
      "static/chunks/turbopack-fe5822370605586b.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0df4ab14cacdbef8.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/fc570204ed8108e3.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-779fb214b685e049.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];