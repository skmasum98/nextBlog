var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__691ea970._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/[root-of-the-server]__9e8f3dd2._.js")
R.m(96331)
R.m(3802)
module.exports=R.m(3802).exports
