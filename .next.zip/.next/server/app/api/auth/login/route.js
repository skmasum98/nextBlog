var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__461caac3._.js")
R.c("server/chunks/[root-of-the-server]__9e8f3dd2._.js")
R.c("server/chunks/[root-of-the-server]__fcb1b18e._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(9606)
R.m(6617)
module.exports=R.m(6617).exports
