var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__5ed24489._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(79543)
R.m(8203)
module.exports=R.m(8203).exports
