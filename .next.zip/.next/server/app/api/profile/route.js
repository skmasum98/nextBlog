var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/profile/route.js")
R.c("server/chunks/[root-of-the-server]__561bc39d._.js")
R.c("server/chunks/[root-of-the-server]__9e8f3dd2._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/node_modules_3e6c0947._.js")
R.m(61499)
R.m(76314)
module.exports=R.m(76314).exports
