var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/route.js")
R.c("server/chunks/[root-of-the-server]__7baa0349._.js")
R.c("server/chunks/[root-of-the-server]__9e8f3dd2._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/node_modules_3e6c0947._.js")
R.m(45084)
R.m(15771)
module.exports=R.m(15771).exports
