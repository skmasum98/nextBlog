var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/[userId]/route.js")
R.c("server/chunks/[root-of-the-server]__01bf5d42._.js")
R.c("server/chunks/[root-of-the-server]__9e8f3dd2._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/node_modules_3e6c0947._.js")
R.m(10044)
R.m(23649)
module.exports=R.m(23649).exports
