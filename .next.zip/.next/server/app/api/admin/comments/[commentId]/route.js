var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/comments/[commentId]/route.js")
R.c("server/chunks/[root-of-the-server]__b6e31e0a._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/node_modules_3e6c0947._.js")
R.m(52811)
R.m(61149)
module.exports=R.m(61149).exports
