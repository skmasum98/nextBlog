var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/posts/[postId]/route.js")
R.c("server/chunks/[root-of-the-server]__0a6b59a9._.js")
R.c("server/chunks/[root-of-the-server]__9e8f3dd2._.js")
R.c("server/chunks/node_modules_3e6c0947._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(26853)
R.m(65308)
module.exports=R.m(65308).exports
