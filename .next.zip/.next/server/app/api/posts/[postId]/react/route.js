var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/posts/[postId]/react/route.js")
R.c("server/chunks/[root-of-the-server]__e05d26a0._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/node_modules_8b580320._.js")
R.m(22263)
R.m(96448)
module.exports=R.m(96448).exports
