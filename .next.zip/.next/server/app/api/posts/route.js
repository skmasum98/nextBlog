var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/posts/route.js")
R.c("server/chunks/[root-of-the-server]__cdba0d73._.js")
R.c("server/chunks/[root-of-the-server]__9e8f3dd2._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/node_modules_8b580320._.js")
R.m(14394)
R.m(17699)
module.exports=R.m(17699).exports
