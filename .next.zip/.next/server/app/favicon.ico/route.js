var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__827bc745._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_f5680d9e.js")
R.m(15934)
R.m(32682)
module.exports=R.m(32682).exports
