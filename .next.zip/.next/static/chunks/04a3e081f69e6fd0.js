__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/5fe48c9cc91f60ec.js",
  "static/chunks/turbopack-fe5822370605586b.js"
])
