__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/5fe48c9cc91f60ec.js",
  "static/chunks/turbopack-b5bbeeff2fa2d723.js"
])
